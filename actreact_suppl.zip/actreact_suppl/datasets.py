from __future__ import unicode_literals, print_function, division
from io import open
import unicodedata
import string
import re
import random
import os
import time
import math
import h5py
import pandas as pd


import torch
import torch.nn as nn
import torch.utils.data
from torch.utils.data import Dataset
from torch import optim
import torch.nn.functional as F
from torchvision import datasets, transforms


import numpy as np
import utils
import matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib import animation, rc

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class ActReactDataset(Dataset):
    def __init__(self, train=True, loc='actreact_h5_data2', gaze_transform=None, joy_transform=None):
        self.loc = loc
        self.train = train
        self.good_inds = self._get_good_inds()
        if self.train:
            self.frames = self._get_train_frames()
        else:
            self.frames = self._get_test_frames()
        self.gaze_transform = gaze_transform
        self.joy_transform = joy_transform
    
    def __getitem__(self, index):
        frame_ind, file = self.frames[index].split(' ')
        
        im1 = np.zeros((64, 64, 1))
        im2 = np.zeros((64, 64, 1))
        with h5py.File(file, 'r') as vid:
            im1 = vid['gaze_ims'][int(frame_ind)][:].reshape(64,64,1)
            im2 = vid['joy_ims'][int(frame_ind)][:].reshape(64,64,1)
        
        if self.gaze_transform:
            im1 = self.gaze_transform(im1)
        
        if self.joy_transform:
            im2 = self.joy_transform(im2)
            
        if type(im1) == torch.Tensor and type(im2) == torch.Tensor:
            im = torch.zeros((64*2, 64))
        else:
            im = np.zeros((64*2, 64, 1))
            
        im[:64] = im1
        im[64:] = im2
        
        return im

    def __len__(self):
        return len(list(self.frames.keys()))
    
    def _get_good_inds(self):
        return torch.arange(1000)
#         good_inds = []
#         for i in range(1000):
#             data = np.load(os.path.join('data', '{:05d}.npz'.format(i)))
#             if data['poses'].shape[0] < 1000:
#                 good_inds.append(i)
#         good_inds = torch.Tensor(good_inds)
#         return good_inds
    
    def _get_frames(self, inds):
        frames = {}
        count=0
        for ind in inds:
            with h5py.File(os.path.join(self.loc, '{:05d}.h5'.format(int(ind))), 'r') as data:
                for i in range(data['poses'][:].shape[0]):
                    frames[count]='{:d} {}/{:05d}.h5'.format(int(i),self.loc,int(ind))
                    count+=1
        return frames
    
    def _get_train_frames(self):
        return self._get_frames(self.good_inds[:-100])
    
    def _get_test_frames(self):
        return self._get_frames(self.good_inds[-100:])

    
class ActReactSeqDataset(ActReactDataset):
    def __getitem__(self, index):
        seq = self.frames[index]

        input_seq = seq['input']
        target_seq = seq['target']
        file = seq['file']
        
        input = torch.zeros((input_seq.shape[0], 64*2, 64))
        target = torch.zeros((target_seq.shape[0], 64*2, 64))
        
        with h5py.File(file, 'r') as vid:
            gaze_vid = vid['gaze_ims']
            joy_vid = vid['joy_ims']
            for i,inp in enumerate(input_seq):
                input[i,:64] = self.gaze_transform(gaze_vid[int(inp)][:].reshape(64,64,1))
                input[i,64:] = self.joy_transform(joy_vid[int(inp)][:].reshape(64,64,1))
            
            for i,tgt in enumerate(target_seq):
                target[i,:64] = self.gaze_transform(gaze_vid[int(tgt)][:].reshape(64,64,1))
                target[i,64:] = self.joy_transform(joy_vid[int(tgt)][:].reshape(64,64,1))
            
        return (input, target, file)

    def _get_frames(self, inds):
        frames = {}
        count=0
        for ind in inds:
            with h5py.File(os.path.join(self.loc, '{:05d}.h5'.format(int(ind))), 'r') as data:
                mov_inds = np.arange(data['poses'][:].shape[0])
                not_moving = data['poses'][:][:,-1] == 0
                seq_inds = np.where(np.array([i==j for i,j in zip(not_moving, not_moving[1:])]) == False)[0]+1
                inps = []
                tgts = []
                files = []
                for i in range(len(seq_inds)+1):
                    if i == 0:
                        seq = mov_inds[:seq_inds[0]]
                    elif i == len(seq_inds):
                        seq = mov_inds[seq_inds[-1]:]
                    else:
                        seq = mov_inds[seq_inds[i-1]:seq_inds[i]]
                        
                    if i % 2 == 0:
                        inps.append(seq)
                        files.append(os.path.join(self.loc, '{:05d}.h5'.format(int(ind))))
                        
                    if (i-1) % 2 == 0:
                        tgts.append(seq)
                
                for inp,tgt,f in zip(inps,tgts,files):
                    frames[count] = {
                        'input': inp,
                        'target': tgt,
                        'file': f,
                    }        
                    count+=1
        return frames
    
        
class ActReactPoseDataset(ActReactDataset):
    def __getitem__(self, index):
        frame_ind, file = self.frames[index].split(' ')
        
        gaze = np.zeros((10**2, 1))
        joy = np.zeros((10**2, 1))
        with h5py.File(file, 'r') as vid:
            pose = vid['poses'][int(frame_ind)][:]

        gaze_ind, joy_ind = np.ravel_multi_index(
            (
                (int(pose[0]), int(pose[1])), ## gaze_x, gaze_y
                (int(pose[3]), int(pose[4]))  ## joy_x, joy_y
            ), 
            (10,10) ## Image size
        )
        gaze[gaze_ind] = 1
        joy[joy_ind] = 1
        
        if self.gaze_transform:
            gaze = self.gaze_transform(gaze)
        
        if self.joy_transform:
            joy = self.joy_transform(joy)
            
        if type(gaze) == torch.Tensor and type(joy) == torch.Tensor:
            gazejoy = torch.zeros((10**2))
        else:
            gazejoy = np.zeros(((10**2*2), 1))
            
        gazejoy[:10**2] = gaze
        gazejoy[10**2:] = joy
        
        return gazejoy
    
class ActReactSeqPoseDataset(ActReactSeqDataset):
    def __getitem__(self, index):
        seq = self.frames[index]

        input_seq = seq['input']
        target_seq = seq['target']
        file = seq['file']
        
        input = torch.zeros((input_seq.shape[0], (10**2)*2))
        target = torch.zeros((target_seq.shape[0], (10**2)*2))
        
        with h5py.File(file, 'r') as vid:
            inp_poses = vid['poses'][input_seq[0]:input_seq[-1]][:].astype(int).T
            inp_gaze_inds = np.ravel_multi_index(inp_poses[0:2,:], (10,10))
            inp_joy_inds = np.ravel_multi_index(inp_poses[3:5,:], (10,10))

            tgt_poses = vid['poses'][target_seq[0]:target_seq[-1]][:].astype(int).T
            tgt_gaze_inds = np.ravel_multi_index(tgt_poses[0:2,:], (10,10))
            tgt_joy_inds = np.ravel_multi_index(tgt_poses[3:5,:], (10,10))
            
            for i,(g,j) in enumerate(zip(inp_gaze_inds, inp_joy_inds)):
                input[i,g] = 1
                input[i,10**2+j] = 1
            
            for i,(g,j) in enumerate(zip(tgt_gaze_inds, tgt_joy_inds)):
                target[i,g] = 1
                target[i,10**2+j] = 1
            
        return (input, target, file)
    
    
class ActReactMicroClassificationDataset(ActReactSeqDataset):
    """
    Micro classification
    for streams in {'gaze', 'joy', 'both'}
    for embedding in {'binary', 'real', 'diff'}
    """
    def __init__(self, train=True, loc='actreact_h5_data3', gaze_transform=None, 
                 joy_transform=None, streams='both', embed='real', 
                 lbls=['s', 'f', 'p'], frame_set=None, part_set=None):
        super().__init__(train=train, loc=loc, gaze_transform=gaze_transform, joy_transform=joy_transform)
        self.streams = streams
        self.embed = embed
        self.lbls = lbls
        self.factor = 2 if self.streams == 'both' else 1
        if self.embed == 'real':
            self.embedding_size = 2
        elif self.embed == 'binary':
            self.embedding_size = (10**2)         
        else:
            self.embedding_size = 2  
        self.tot_embedding_size = self.factor * self.embedding_size
    
    
    def one_hot_encode(self, lbl, lbls):
        onehot = np.zeros(len(lbls))
        for i,l in enumerate(lbls):
            if lbl == l:
                onehot[i] = 1
        return onehot
    
    def __getitem__(self, index):
        seq, lbl, file = self.frames[index]
        
        lbl = self.one_hot_encode(lbl, self.lbls)
        if self.embed == 'real':
            feat_size = seq.shape[0]
        elif self.embed == 'binary':
            feat_size = seq.shape[0]
        else:
            feat_size = seq.shape[0]-1 if seq.shape[0]-1 > 0 else seq.shape[0]
        
        input = torch.zeros((feat_size, self.tot_embedding_size))
        
        with h5py.File(file, 'r') as vid:
            
            inp_poses = vid['poses'][seq[0]:seq[-1]+1][:]
            
            if self.embed == 'real':
                inp_gaze = inp_poses[:,0:2]
                inp_joy = inp_poses[:,3:5]
                
                if self.streams == 'gaze' or self.streams == 'both':    
                    input[:, :2] = torch.from_numpy(inp_gaze)
                    
                if self.streams == 'joy' or self.streams == 'both': 
                    if self.streams == 'joy':
                        input[:, :2] = torch.from_numpy(inp_joy)
                    else:
                        input[:, 2:] = torch.from_numpy(inp_joy)
                
            elif self.embed == 'binary':
                inp_poses = inp_poses.astype(int).T
                
                inp_gaze = np.ravel_multi_index(inp_poses[0:2,:].clip(0,9), (10,10))
                inp_joy = np.ravel_multi_index(inp_poses[3:5,:].clip(0,9), (10,10))
                
                if self.streams == 'gaze' or self.streams == 'both':    
                    for i,g in enumerate(inp_gaze):
                        input[i,g] = 1
                    
                if self.streams == 'joy' or self.streams == 'both':    
                    offset = self.embedding_size if self.streams == 'both' else 0
                    for i,j in enumerate(inp_joy):
                        input[i,offset+j] = 1
                        
            elif self.embed == 'diff':
                inp_gaze = inp_poses[:,0:2]
                inp_joy = inp_poses[:,3:5]

                if seq.shape[0]-1 > 0:
                    inp_gaze = inp_gaze[1:] - inp_gaze[:-1]
                    inp_joy = inp_joy[1:] - inp_joy[:-1]
                
                if self.streams == 'gaze' or self.streams == 'both':    
                    input[:, :2] = torch.from_numpy(inp_gaze)
                
                if self.streams == 'joy' or self.streams == 'both': 
                    if self.streams == 'joy':
                        input[:, :2] = torch.from_numpy(inp_joy)
                    else:
                        input[:, 2:] = torch.from_numpy(inp_joy)
        return (input, lbl, file)
    
    def _get_frames(self, inds):
        
        def _get_seq_inds(seq, lbl):
            tmp = []
            for k,(i,j) in enumerate(zip(seq,seq[1:])):
                if k == 0 and i == True:
                    tmp.append(k)
                if k == len(seq)-2 and j == True:
                    tmp.append(k+1)
                if i != j:
                    tmp.append(k+1)
            start_inds = np.array(tmp[::2])
            stop_inds = np.array(tmp[1::2])
            lbls = np.tile(lbl, start_inds.shape[0])
            return start_inds, stop_inds, lbls
        
        frames = {}
        count=0
        for ind in inds:
            fname = os.path.join(self.loc, '{:05d}.h5'.format(int(ind)))
            with h5py.File(fname, 'r') as data:
                movie_inds = np.arange(data['poses'][:].shape[0])
                gaze_lbls = data['poses'][:][:,2]
                
                saccades = gaze_lbls == 0
                sac_start, sac_end, sac_lbl = _get_seq_inds(saccades, 's')
                
                fixations = gaze_lbls == 1
                fix_start, fix_end, fix_lbl = _get_seq_inds(fixations, 'f')
                
                pursuits = gaze_lbls == 2
                pur_start, pur_end, pur_lbl = _get_seq_inds(pursuits, 'p')
                
                starts = np.hstack((sac_start,fix_start,pur_start))
                ends = np.hstack((sac_end,fix_end,pur_end))
                lbls = np.hstack((sac_lbl,fix_lbl,pur_lbl))
                
                for s,e,l in zip(starts, ends, lbls):
                    if s >= e:
                        continue
                    frames[count] = [movie_inds[s:e], l, fname]
                    count+=1
        return frames
    
    
class ActReactMacroClassificationDataset(ActReactMicroClassificationDataset):
    """
    Macro classification using:
        gaze: embedding into 10x10 occupancy grid
        joy: None
    """
    def __init__(self, train=True, loc='actreact_h5_data3', gaze_transform=None, 
                 joy_transform=None, streams='both', embed='real', 
                 lbls=['e', 'c', 'p', 'ms', 't'], frame_set=None, part_set=None):
        super().__init__(
            train=train, 
            loc=loc, 
            gaze_transform=gaze_transform, 
            joy_transform=joy_transform,
            streams=streams, 
            embed=embed,
            lbls=lbls,
        )

        self.streams = streams
        self.embed = embed
        
    def _get_frames(self, inds):

        def _get_seq_inds(seq, lbl):
            tmp = []
            for k,(i,j) in enumerate(zip(seq,seq[1:])):
                if k == 0 and i == True:
                    tmp.append(k)
                if k == len(seq)-2 and j == True:
                    tmp.append(k+1)
                if i != j:
                    tmp.append(k+1)
            start_inds = np.array(tmp[::2])
            stop_inds = np.array(tmp[1::2])
            lbls = np.tile(lbl, start_inds.shape[0])
            return start_inds, stop_inds, lbls
        
        frames = {}
        count=0
        for ind in inds:
            fname = os.path.join(self.loc, '{:05d}.h5'.format(int(ind)))
            with h5py.File(fname, 'r') as data:
                movie_inds = np.arange(data['poses'][:].shape[0])
                macro_lbls = data['poses'][:][:,-1]
                starts =[]
                ends = []
                lbls = []
                for n,nl in zip(range(len(['e', 'c', 'p', 'ms', 't'])), ['e', 'c', 'p', 'ms', 't']):
                    inds = macro_lbls == n
                    t_start, t_end, t_lbl = _get_seq_inds(inds, nl)
                    starts.append(t_start)
                    ends.append(t_end)
                    lbls.append(t_lbl)
                
                starts = np.hstack(starts).astype(int)
                ends = np.hstack(ends).astype(int)
                lbls = np.hstack(lbls)
                for s,e,l in zip(starts, ends, lbls):
                    if s >= e:
                        continue
                    frames[count] = [movie_inds[s:e], l, fname]
                    count+=1
        return frames
    
class HARMONICMicroClassificationDataset(ActReactSeqDataset):
    """
    Micro classification
    for streams in {'gaze', 'joy', 'both'}
    for embedding in {'binary', 'real', 'diff'}
    """
    def __init__(self, train=True, gaze_transform=None, 
                 joy_transform=None, streams='both', embed='real',
                 harmonic_home='/mnt/harpdata/harmonic_public/harmonic_0.4.0/',
                frame_set=None,
                part_set=None):
        self.train = train
        self.harmonic_home = harmonic_home
        self.good_inds = self._get_good_inds()
        self.part_set = part_set
        
        if type(frame_set) != type(None):
            self.frames = self._get_all_frames()
            self.frames = {i:self.frames[k] for i,k in enumerate(frame_set)}
        else:
            if self.train:
                self.frames = self._get_train_frames()
            else:
                self.frames = self._get_test_frames()
        
        self.gaze_transform = gaze_transform
        self.joy_transform = joy_transform
        
        self.streams = streams
        self.embed = embed
        self.lbls = [0, 1, 2]
        self.g = (self.streams == 'gaze') or (self.streams == 'both')
        self.j = (self.streams == 'joy') or (self.streams == 'both')

        if self.embed == 'real':
            self.embedding_size = self.g * 3 + self.j * 5
        elif self.embed == 'binary':
            self.embedding_size = self.g *(10**2) + self.j *(10**2)
        else:
            self.embedding_size = self.g * 3 + self.j * 5

        self.trials = self.trials[self.good_inds]
        
        if streams == 'gaze' or streams == 'both':
            self.gaze_data = utils.smooth_gaze(utils.get_gaze_data(self.trials))
            
        if streams == 'joy' or streams == 'both':
            self.joy_data = utils.smooth_joystick(utils.get_joystick_data(self.trials))

        self.tot_embedding_size = self.embedding_size
    
    
    def one_hot_encode(self, lbl, lbls):
        onehot = np.zeros(len(lbls))
        for i,l in enumerate(lbls):
            if lbl == l:
                onehot[i] = 1
        return onehot
    
    def __getitem__(self, index):
        seq, lbl, file = self.frames[index]
        
        lbl = self.one_hot_encode(lbl, self.lbls)
        
        if self.embed == 'real':
            feat_size = seq.shape[0]
        elif self.embed == 'binary':
            feat_size = seq.shape[0]
        else:
            feat_size = seq.shape[0]-1 if seq.shape[0]-1 > 0 else seq.shape[0]
        
        input = torch.zeros((feat_size, self.tot_embedding_size))
        
        ed = self.gaze_data[file][:,seq].T
        ed[np.isnan(ed)] = 0
        if self.j:
            jd = self.joy_data[file][:,seq].T
        
        if self.embed == 'real':
            if self.streams == 'gaze' or self.streams == 'both': 
                inp_gaze = ed
                input[:, :3] = torch.from_numpy(inp_gaze)

            if self.streams == 'joy' or self.streams == 'both':
                inp_joy = jd
                if self.streams == 'joy':
                    input[:, :5] = torch.from_numpy(inp_joy)
                else:
                    input[:, 3:] = torch.from_numpy(inp_joy)

        elif self.embed == 'binary':
            if self.streams == 'gaze' or self.streams == 'both':
                inp_gaze = np.ravel_multi_index((ed[:,:2].T.clip(0,1)*9).astype(int), (10,10))
                for i,g in enumerate(inp_gaze):
                    input[i,g] = 1
                    
            if self.streams == 'joy' or self.streams == 'both':
                inp_joy = np.ravel_multi_index((((jd[:,:2].T+1)/2)*9).astype(int), (10,10))
                offset = self.embedding_size//2 if self.streams == 'both' else 0
                for i,j in enumerate(inp_joy):
                    input[i,offset+j] = 1

        elif self.embed == 'diff':

            if self.streams == 'gaze' or self.streams == 'both':  
                inp_gaze = ed
                if seq.shape[0]-1 > 0:
                    input[:, 0:2] = torch.from_numpy(inp_gaze[1:, 0:2] - inp_gaze[:-1, 0:2])
                    input[:, 2] = torch.from_numpy((inp_gaze[1:, 2] + inp_gaze[:-1, 2]) / 2)
                else:
                    input[:, :2] = torch.from_numpy(inp_gaze)

            if self.streams == 'joy' or self.streams == 'both':
                inp_joy = jd
                if seq.shape[0]-1 > 0:
                    if self.streams == 'joy':
                        input[:,:2] = torch.from_numpy(inp_joy[1:,:2] - inp_joy[:-1,:2])
                        input[:,2:] = torch.from_numpy(inp_joy[:-1,2:])
                    else:
                        input[:,3:5] = torch.from_numpy(inp_joy[1:,:2] - inp_joy[:-1,:2])
                        input[:,5:] = torch.from_numpy(inp_joy[:-1,2:])
                else:        
                    if self.streams == 'joy':
                        input[:, :5] = torch.from_numpy(inp_joy)
                    else:
                        input[:, 3:] = torch.from_numpy(inp_joy)

                    
        return (input, lbl, file)
    
    def _get_good_inds(self):
        self.trials = utils.get_trials(self.harmonic_home, 0)
        self.gaze_data = utils.get_gaze_data(self.trials)
            
        means = np.zeros(len(self.trials))
        for i, trial in enumerate(self.trials):
            part = trial.split('/')
            means[i] = np.mean(self.gaze_data[trial][2])

        vels = np.zeros(len(self.trials))
        for i, trial in enumerate(self.trials):
            pos_x_diff = np.diff(self.gaze_data[trial][0])
            pos_y_diff = np.diff(self.gaze_data[trial][1])
            vels[i] = np.mean(np.sqrt(pos_x_diff**2 + pos_y_diff**2))

        good_conf = np.where(means > .9)[0]
        good_vel = np.where(np.abs(vels - 0) < .5)[0]
        good_inds = np.intersect1d(good_conf, good_vel)
        
        return good_inds
    
    def _get_all_frames(self):
        return self._get_frames(self.good_inds)
    
    def _get_train_frames(self):
        ps = np.array([trial.split('/')[5] for trial in self.trials[self.good_inds]])
        train = self.good_inds[ps!=self.part_set]
        return self._get_frames(train)
    
    def _get_test_frames(self):
        ps = np.array([trial.split('/')[5] for trial in self.trials[self.good_inds]])
        test = self.good_inds[ps==self.part_set]
        return self._get_frames(test)
    
    def _get_frames(self, inds):
        def get_seqs(seq):
            cur_l = seq[0,1]
            cur_i = 0
            seqs = []
            while cur_i < len(seq)-2:
                f, l, t = seq[cur_i]
                tmp = []
                while l == cur_l and cur_i+1 < len(seq):
                    tmp.append(seq[cur_i])
                    cur_i += 1
                    f, l, t = seq[cur_i]
                cur_l = l
                tmp = np.array(tmp, dtype=int)
                tmp[:,0] -= 1
                seqs.append(tmp)
            return seqs
        
        frames = {}
        count=0
        for ind in inds:
            lbls_fname = os.path.join('ibdt_lbls' + self.trials[ind], 'classification.csv')
            gaze_fname = os.path.join('/' + self.trials[ind], 'text_data/gaze_positions.csv')
            joy_fname = os.path.join('/' + self.trials[ind], 'text_data/ada_joy.csv')
            gaze = pd.read_csv(gaze_fname)
            joy = pd.read_csv(joy_fname)
            seq_len = min(len(np.unique(gaze.world_index_corrected.values)), len(np.unique(joy.world_index_corrected.values)))

            
            lbls = pd.read_csv(lbls_fname, header=None).values[:seq_len, :]

            # get labels
            seqs = get_seqs(lbls)
            
            for seq in seqs:
                if len(seq) < 2 or seq[0, 1] not in [0, 1, 2] :
                    continue
                frames[count] = [seq[:,0], seq[0,1], self.trials[ind]]
                count+=1 

        return frames
    
class HARMONICMacroClassificationDataset(ActReactSeqDataset):
    """
    Macro classification
    for streams in {'gaze', 'joy', 'both'}
    for embedding in {'binary', 'real', 'diff'}
    """
    def __init__(self, train=True, gaze_transform=None, 
                 joy_transform=None, streams='both', embed='real',
                 harmonic_home='/mnt/harpdata/harmonic_public/harmonic_0.4.0/',
                frame_set=None,
                part_set=None):
        self.train = train
        self.frame_set = frame_set
        self.part_set = part_set
        
        self.harmonic_home = harmonic_home
        self.remap = {
            0:0,
            1:1,
            2:2,
            4:3,
            7:4,
        }
        self.trials = np.array([
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p101/run/005',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p101/run/006',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p101/run/007',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p101/run/008',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p101/run/009',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p106/run/000',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p106/run/001',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p106/run/004',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p107/run/006',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p107/run/007',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p107/run/008',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p107/run/009',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p108/run/015',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p108/run/016',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p108/run/018',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p108/run/019',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p109/run/010',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p109/run/011',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p109/run/012',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p109/run/013',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p109/run/014',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p110/run/015',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p110/run/016',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p110/run/017',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p110/run/018',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p111/run/011',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p111/run/012',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p111/run/013',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p111/run/014',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p112/run/005',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p112/run/006',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p112/run/007',
            '/mnt/harpdata/harmonic_public/harmonic_0.4.0/p112/run/008',
        ])
        self.good_inds = np.arange(len(self.trials))#self._get_good_inds()
        
        if type(frame_set) != type(None):
            self.frames = self._get_all_frames()
            self.frames = {i:self.frames[k] for i,k in enumerate(frame_set)}
        else:
            if self.train:
                self.frames = self._get_train_frames()
            else:
                self.frames = self._get_test_frames()
        
        self.gaze_transform = gaze_transform
        self.joy_transform = joy_transform
        
        self.streams = streams
        self.embed = embed
        self.lbls = [0, 1, 2, 3, 4]
        self.g = (self.streams == 'gaze') or (self.streams == 'both')
        self.j = (self.streams == 'joy') or (self.streams == 'both')

        if self.embed == 'real':
            self.embedding_size = self.g * 3 + self.j * 5
        elif self.embed == 'binary':
            self.embedding_size = self.g *(10**2) + self.j *(10**2)
        else:
            self.embedding_size = self.g * 3 + self.j * 5

        if streams == 'gaze' or streams == 'both' or streams == 'joy':
            self.gaze_data = utils.smooth_gaze(utils.get_gaze_data(self.trials))
            
        if streams == 'joy' or streams == 'both':
            self.joy_data = utils.smooth_joystick(utils.get_joystick_data(self.trials))

        self.tot_embedding_size = self.embedding_size
    
    
    def one_hot_encode(self, lbl, lbls):
        onehot = np.zeros(len(lbls))
        for i,l in enumerate(lbls):
            if lbl == l:
                onehot[i] = 1
        return onehot
    
    def __getitem__(self, index):
        seq, lbl, file = self.frames[index]
        
        lbl = self.one_hot_encode(lbl, self.lbls)
        
        if self.embed == 'real':
            feat_size = seq.shape[0]
        elif self.embed == 'binary':
            feat_size = seq.shape[0]
        else:
            feat_size = seq.shape[0]-1 if seq.shape[0]-1 > 0 else seq.shape[0]
        
        input = torch.zeros((feat_size, self.tot_embedding_size))
        
        ed = self.gaze_data[file][:,seq].T
        ed[np.isnan(ed)] = 0
        if self.j:
            jd = self.joy_data[file][:,seq].T
        
        if self.embed == 'real':
            if self.streams == 'gaze' or self.streams == 'both': 
                inp_gaze = ed
                input[:, :3] = torch.from_numpy(inp_gaze)

            if self.streams == 'joy' or self.streams == 'both':
                inp_joy = jd
                if self.streams == 'joy':
                    input[:, :5] = torch.from_numpy(inp_joy)
                else:
                    input[:, 3:] = torch.from_numpy(inp_joy)

        elif self.embed == 'binary':
            if self.streams == 'gaze' or self.streams == 'both':
                inp_gaze = np.ravel_multi_index((ed[:,:2].T.clip(0,1)*9).astype(int), (10,10))
                for i,g in enumerate(inp_gaze):
                    input[i,g] = 1
                    
            if self.streams == 'joy' or self.streams == 'both':
                inp_joy = np.ravel_multi_index((((jd[:,:2].T+1)/2)*9).astype(int), (10,10))
                offset = self.embedding_size//2 if self.streams == 'both' else 0
                for i,j in enumerate(inp_joy):
                    input[i,offset+j] = 1

        elif self.embed == 'diff':

            if self.streams == 'gaze' or self.streams == 'both':  
                inp_gaze = ed
                if seq.shape[0]-1 > 0:
                    input[:, 0:2] = torch.from_numpy(inp_gaze[1:, 0:2] - inp_gaze[:-1, 0:2])
                    input[:, 2] = torch.from_numpy((inp_gaze[1:, 2] + inp_gaze[:-1, 2]) / 2)
                else:
                    input[:, :2] = torch.from_numpy(inp_gaze)

            if self.streams == 'joy' or self.streams == 'both':
                inp_joy = jd
                if seq.shape[0]-1 > 0:
                    if self.streams == 'joy':
                        input[:,:2] = torch.from_numpy(inp_joy[1:,:2] - inp_joy[:-1,:2])
                        input[:,2:] = torch.from_numpy(inp_joy[:-1,2:])
                    else:
                        input[:,3:5] = torch.from_numpy(inp_joy[1:,:2] - inp_joy[:-1,:2])
                        input[:,5:] = torch.from_numpy(inp_joy[:-1,2:])
                else:        
                    if self.streams == 'joy':
                        input[:, :4] = torch.from_numpy(inp_joy)
                    else:
                        input[:, 3:] = torch.from_numpy(inp_joy)

                    
        return (input, lbl, file)
    
    def _get_good_inds(self):
        return [
            '',
        ]
        self.trials = utils.get_trials(self.harmonic_home, 0)
        self.gaze_data = utils.get_gaze_data(self.trials)
            
        means = np.zeros(len(self.trials))
        for i, trial in enumerate(self.trials):
            part = trial.split('/')
            means[i] = np.mean(self.gaze_data[trial][2])

        vels = np.zeros(len(self.trials))
        for i, trial in enumerate(self.trials):
            pos_x_diff = np.diff(self.gaze_data[trial][0])
            pos_y_diff = np.diff(self.gaze_data[trial][1])
            vels[i] = np.mean(np.sqrt(pos_x_diff**2 + pos_y_diff**2))

        good_conf = np.where(means > .9)[0]
        good_vel = np.where(np.abs(vels - 0) < .5)[0]
        good_inds = np.intersect1d(good_conf, good_vel)
        
        return good_inds
    
    def _get_all_frames(self):
        return self._get_frames(self.good_inds)
    
    def _get_train_frames(self):
        ps = np.array([trial.split('/')[5] for trial in self.trials])
        good_inds = np.arange(len(self.trials))
        train = good_inds[ps!=self.part_set]
        return self._get_frames(train)
    
    def _get_test_frames(self):
        ps = np.array([trial.split('/')[5] for trial in self.trials])
        good_inds = np.arange(len(self.trials))
        test = good_inds[ps==self.part_set]
        return self._get_frames(test)
    
    def _get_frames(self, inds):
        def get_seqs(seq):
            cur_n = seq[0,2]
            cur_i = 0
            seqs = []
            while cur_i < len(seq)-2:
                f, l, n = seq[cur_i]
                tmp = []
                while n == cur_n and cur_i+1 < len(seq):
                    tmp.append(seq[cur_i])
                    cur_i += 1
                    f, l, n = seq[cur_i]
                cur_n = n
                tmp = np.array(tmp, dtype=int)
                seqs.append(tmp)
            return seqs
        
        frames = {}
        count=0
        for ind in inds:
            lbls_fname = os.path.join('macro_lbls' + self.trials[ind], 'macro_labels/macro_labels_post.py')
            gaze_fname = os.path.join('/' + self.trials[ind], 'text_data/gaze_positions.csv')
            joy_fname = os.path.join('/' + self.trials[ind], 'text_data/ada_joy.csv')
            gaze = pd.read_csv(gaze_fname)
            joy = pd.read_csv(joy_fname)
            seq_len = min(
                len(np.unique(gaze.world_index_corrected.values)), 
                len(np.unique(joy.world_index_corrected.values))
            )

            lbls = utils.load(lbls_fname)[:seq_len, :]
            
            # get labels
            seqs = get_seqs(lbls)
            
            for seq in seqs:
                if len(seq) < 2 or seq[0, 1] not in [0, 1, 2, 4, 7] :
                    continue
                frames[count] = [seq[:,0], self.remap[seq[0,1]], self.trials[ind]]
                count+=1 
        return frames