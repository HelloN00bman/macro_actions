#!/bin/bash

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p101 &
CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p102 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p105 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p106 &
wait

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p107 &
CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p108 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p109 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p110 &
wait

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p111 &
CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p112 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p113 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p114 &
wait

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p115 &
CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p117 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p118 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p119 &
wait

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p121 &
CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p122 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_harmonic_micro_valid -v p123 &
wait

