#!/bin/bash

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s gaze -em binary -hs 256 -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em real -hs 256 -r results_actreact_micro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em real -hs 16 -r results_actreact_micro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em diff -hs 256 -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s gaze -em diff -hs 16 -r results_actreact_micro -data ActReact &
wait

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s joy -em binary -hs 256 -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s joy -em real -hs 256 -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s joy -em real -hs 16 -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s joy -em diff -hs 256 -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s joy -em diff -hs 16 -r results_actreact_micro -data ActReact &
wait

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s both -em binary -hs 256 -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s both -em real -hs 256 -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s both -em real -hs 16 -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s both -em diff -hs 256 -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s both -em diff -hs 16 -r results_actreact_micro -data ActReact &
wait

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t micro -s both -em binary -hs 256 -lf True -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s both -em real -hs 256 -lf True -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s both -em real -hs 16 -lf True -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s both -em diff -hs 256 -lf True -r results_actreact_micro -data ActReact &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t micro -s both -em diff -hs 16 -lf True -r results_actreact_micro -data ActReact &
wait
