#!/bin/bash


CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t macro -s gaze -em binary -hs 256 -r results_actreact_macro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s gaze -em real -hs 256 -r results_actreact_macro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s gaze -em real -hs 16 -r results_actreact_macro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s gaze -em diff -hs 256 -r results_actreact_macro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s gaze -em diff -hs 16 -r results_actreact_macro -data ActReact&
wait

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t macro -s joy -em binary -hs 256 -r results_actreact_macro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s joy -em real -hs 256 -r results_actreact_macro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s joy -em real -hs 16 -r results_actreact_macro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s joy -em diff -hs 256 -r results_actreact_macro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s joy -em diff -hs 16 -r results_actreact_macro -data ActReact&
wait

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t macro -s both -em binary -hs 256 -r results_actreact_macro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s both -em real -hs 256 -r results_actreact_macro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s both -em real -hs 16 -r results_actreact_macro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s both -em diff -hs 256 -r results_actreact_macro -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s both -em diff -hs 16 -r results_actreact_macro -data ActReact&
wait

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t macro -s both -em binary -hs 256 -r results_actreact_macro -lf True -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s both -em real -hs 256 -r results_actreact_macro -lf True -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s both -em real -hs 16 -r results_actreact_macro -lf True -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s both -em diff -hs 256 -r results_actreact_macro -lf True -data ActReact&
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s both -em diff -hs 16 -r results_actreact_macro -lf True -data ActReact&
wait
