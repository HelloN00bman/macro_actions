#!/bin/bash

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t macro -s both -em real -hs 256 -r results_harmonic_macro_valid -v p101 &
CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t macro -s both -em real -hs 256 -r results_harmonic_macro_valid -v p106 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s both -em real -hs 256 -r results_harmonic_macro_valid -v p107 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s both -em real -hs 256 -r results_harmonic_macro_valid -v p108 &
wait

CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t macro -s both -em real -hs 256 -r results_harmonic_macro_valid -v p109 &
CUDA_VISIBLE_DEVICES=0 python solver.py -d cuda -t macro -s both -em real -hs 256 -r results_harmonic_macro_valid -v p110 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s both -em real -hs 256 -r results_harmonic_macro_valid -v p111 &
CUDA_VISIBLE_DEVICES=1 python solver.py -d cuda -t macro -s both -em real -hs 256 -r results_harmonic_macro_valid -v p112 &
wait
