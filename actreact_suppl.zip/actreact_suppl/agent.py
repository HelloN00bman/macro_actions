import numpy as np

class Agent(object):
    def dist_to(self, heading):
        return np.sqrt(np.sum((self.position[:2] - heading[:2])**2))
    
    def angle_to(self, heading):
        dist = heading[:2] - self.position[:2]
        sign = (1,1)
        if dist[0] >= 0 and dist[1] >= 0:
            sign = (1,1)
            if dist[0] == 0:
                return np.pi / 2, sign
        elif dist[0] >= 0 and dist[1] < 0:
            sign = (1,-1) 
            if dist[0] == 0:
                return 3*np.pi / 2, (1,1)
        elif dist[0] < 0 and dist[1] < 0:
            sign = (-1,-1)    
        elif dist[0] < 0 and dist[1] >= 0:
            sign = (-1,1)
        return np.abs(np.arctan(dist[1] / dist[0])), sign


class JoyAgent(Agent):
    def __init__(self, mu_vel, sigma_vel, position, heading):
        # noise parameters for joystick speed
        self.mu_vel = mu_vel
        self.sigma_vel = sigma_vel
        
        # current position [x, y]
        self.position = position
        
        self.heading = heading
    
    def hold(self, duration):
        positions = [[self.position[0], self.position[1], 0] for _ in range(duration)]
        return np.array(positions)
    
    def move_to(self, heading, num_frames=None):
        r = self.dist_to(heading)
        theta, sign = self.angle_to(heading)
        speed = np.random.normal(self.mu_vel, self.sigma_vel)
        frame = (r / speed) if num_frames == None else num_frames
        positions = [[self.position[0], self.position[1], 1]]
        while frame>0:
            if frame < 1:
                speed*=frame
            x = self.position[0] + sign[0]*speed * np.cos(theta)
            y = self.position[1] + sign[1]*speed * np.sin(theta)
            r = self.dist_to(heading)
            self.position = np.array([x,y])
            frame -= 1
            positions.append([x,y,1])
        return np.array(positions)
    
    def toggle_to(self, heading, toggle_every, toggle_length):
        r = self.dist_to(heading)
        theta, sign = self.angle_to(heading)
        speed = np.random.normal(self.mu_vel, self.sigma_vel)
        frame = (r / speed)
         
        toggle = 0
        toggle_count = 0
        positions = [[self.position[0], self.position[1], 1]]
        while frame>0:
            if frame < 1:
                speed*=frame
            if int(frame) % toggle_every == 0 and toggle_count < toggle_length:
                toggle = 1
                toggle_count += 1
            else:
                toggle = 0
                toggle_count = 0
                
            x = self.position[0] + sign[0]*speed * np.cos(theta)*(1-toggle)
            y = self.position[1] + sign[1]*speed * np.sin(theta)*(1-toggle)
            r = self.dist_to(heading)
            
            self.position = np.array([x,y])
            positions.append([x,y,1])
            
            frame -= 1*(1-toggle)

        return np.array(positions)
    
    def mode_switch(self, heading):
        r = self.dist_to(heading)
        theta, sign = self.angle_to(heading)
        speed = np.random.normal(self.mu_vel, self.sigma_vel)
        frame = (r / speed)
        count = min(3, frame)
        positions = [[self.position[0], self.position[1], 1]]
        while count>0:
            if frame < 1:
                speed*=frame
            x = self.position[0] + sign[0]*speed * np.cos(theta)
            y = self.position[1] + sign[1]*speed * np.sin(theta)
            r = self.dist_to(heading)
            self.position = np.array([x,y])
            frame -= 1
            positions.append([x,y,1])
        
        return np.array(positions)

class GazeAgent(Agent):
    def __init__(self, mu_vel, sigma_vel, mu_fix, sigma_fix, sigma_x, sigma_y, position, heading):
        # noise parameters for gaze saccade speed
        self.mu_vel = mu_vel
        self.sigma_vel = sigma_vel
        
        # noise parameters for fixation length
        self.mu_fix = mu_fix
        self.sigma_fix = sigma_fix
        
        # noise parameters for positional jitter
        self.sigma_x = sigma_x
        self.sigma_y = sigma_y
        
        # current position [x, y]
        self.position = position
        
        # current heading
        self.heading = heading
    
    def saccade_to(self, heading, num_frames=None):
        r = self.dist_to(heading)
        theta, sign = self.angle_to(heading)
        speed = np.random.normal(self.mu_vel, self.sigma_vel) if num_frames == None else r / num_frames
        frame = (r / speed) if num_frames == None else num_frames
        positions = []
        while frame > 0:
            if frame < 1:
                speed=speed*frame
            x_noise = np.random.normal(0, self.sigma_x)
            y_noise = np.random.normal(0, self.sigma_y)
            x = (self.position[0] + sign[0]*speed * np.cos(theta) + x_noise)
            y = (self.position[1] + sign[1]*speed * np.sin(theta) + y_noise)
            r = self.dist_to(heading)
            positions.append([x,y,0])
            self.position = np.array([x-x_noise,y-y_noise])
            frame -= 1
        return np.array(positions)
    
    def fixate(self, num_frames=None):
        frames = np.random.normal(self.mu_fix, self.sigma_fix) if num_frames == None else num_frames
        
        positions = []
        while frames > 0:
            x = np.random.normal(self.position[0], self.sigma_x)
            y = np.random.normal(self.position[1], self.sigma_y)
            positions.append([x,y,1])
            frames -= 1
        self.position = np.array(positions)[-1]
        return np.array(positions)
    
    def pursue(self, path):
        xs = np.insert(np.random.normal(path[:-1,0], self.sigma_x), 0, self.position[0])
        ys = np.insert(np.random.normal(path[:-1,1], self.sigma_y), 0, self.position[1])
        self.position = np.array([xs[-1],ys[-1]])
        labels = np.ones(xs.shape)*2
        return np.vstack((xs,ys,labels)).T
        
        
        
        
        
        