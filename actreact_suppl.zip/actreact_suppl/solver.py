import os
import os.path
import time
import logging
import argparse


import h5py
import matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib import animation, rc
import numpy as np
import torch
import torch.nn as nn
import torch.utils.data
from torch import optim
from torch.utils.data import BatchSampler, SequentialSampler, RandomSampler, Dataset
import torch.nn.functional as F

from transform import Normalize

from datasets import *
from models import *

from torchvision import datasets, transforms

try:
    import cPickle as thepickle
except ImportError:
    import _pickle as thepickle

torch.set_default_tensor_type(torch.DoubleTensor)

class Solver():
    def __init__(
        self, 
        encoder,
        decoder,
        max_len,
        counts,
        epoch_num, 
        learning_rate, 
        loss,
        resultsdir,
        train_log_file='train.log',
        test_log_file='test.log',
        plot_file='loss_plot.png',
        device=torch.device('cpu'),
        args=None,
        encoder2 = None,
        tform = None,
    ):
        self.args=args
        self.late_fusion = args.late_fusion
        self.tform = tform
        self.encoder = encoder  
        if self.late_fusion:
            self.encoder1 = self.encoder
            self.encoder2 = encoder2
        self.decoder = decoder  
        
        self.MAX_LEN = max_len  # Maximum sequence length
        self.counts = counts  # Class category counts in total number
        
        self.device = device
        
        self.encoder.to(self.device)  # Move model to training device
        if self.late_fusion: self.encoder2.to(self.device)
        self.decoder.to(self.device)  # Move model to training device
        
        self.epoch_num = epoch_num  
        self.epoch_count = 0
        self.loss = loss
        
        encode_params = list(self.encoder1.parameters()) + \
                        list(self.encoder2.parameters())   \
                        if self.late_fusion else           \
                        self.encoder.parameters()
        self.encoder_optimizer = torch.optim.Adam(
            encode_params, 
            lr=learning_rate, 
            weight_decay=1e-5
        )
        
        self.decoder_optimizer = torch.optim.Adam(
            self.decoder.parameters(), 
            lr=learning_rate, 
            weight_decay=1e-5
        )
        
        self.resultsdir = os.path.join(resultsdir, str(len(os.listdir(resultsdir))))
        os.mkdir(self.resultsdir)
        
        formatter = logging.Formatter(
            "[ %(levelname)s : %(asctime)s ] - %(message)s"
        )
        logging.basicConfig(
            level=logging.INFO, format="[ %(levelname)s : %(asctime)s ] - %(message)s"
        )
        self.train_logger = logging.getLogger("Pytorch.Train")
        train_fh = logging.FileHandler(os.path.join(self.resultsdir, train_log_file))
        train_fh.setFormatter(formatter)
        self.train_logger.addHandler(train_fh)
        self.train_logger.info(self.encoder)
        if self.late_fusion: self.train_logger.info(self.encoder2)
        self.train_logger.info(self.decoder)
        self.train_logger.info(self.encoder_optimizer)
        self.train_logger.info(self.decoder_optimizer)
        
        self.test_logger = logging.getLogger("Pytorch.Test")
        test_fh = logging.FileHandler(os.path.join(self.resultsdir, test_log_file))
        test_fh.setFormatter(formatter)
        self.test_logger.addHandler(test_fh)
        self.test_logger.info(self.encoder)
        if self.late_fusion: self.test_logger.info(self.encoder2)
        self.test_logger.info(self.decoder)
        
        self.plot_file = os.path.join(self.resultsdir, plot_file)
            
    def train(self, dataloader, losses, binary, log_every):
        epoch_start_time = time.time()  # grab epoch start time
        
        self.encoder.train()  # put model into training mode
        if self.late_fusion: self.encoder2.train() # put model into training mode
        self.decoder.train()  # put model into training mode
        
        preds = torch.zeros(100, 1)
        confs = torch.zeros(100, self.args.num_classes)
        lbls = torch.zeros(100, 1)
        
        for itr, batch in enumerate(dataloader, start=1):
            self.encoder_optimizer.zero_grad()
            self.decoder_optimizer.zero_grad()
            
            itr_start_time = time.time()
            
            _, target, _, conf = self._get_outputs(batch) if not self.late_fusion \
                                            else self._get_outputs_late_fusion(batch)
            confs[itr-1,:] = conf
            if binary:
                target = batch[1].to(self.device).view(1,-1)
                loss = self.loss(conf, target)
                lbls[itr-1] = target.item()
                preds[itr-1] = (conf > .5).item()
            else:
                target = batch[1].long().to(self.device)
                _, ti = target.topk(1)
                loss = self.loss(conf, ti[0].view(-1).long())
                lbls[itr-1] = ti[0].view(-1).long().item()
                _, pred = conf.topk(1)
                preds[itr-1] = pred.item()
            
            losses.append(loss.item()) #  log the loss

            loss.backward()
            
            if self.args.clip:
                nn.utils.clip_grad_norm_(self.encoder.parameters(), self.args.clip)
                if self.late_fusion: 
                    nn.utils.clip_grad_norm_(self.encoder2.parameters(), self.args.clip)
            
            self.encoder_optimizer.step()
            self.decoder_optimizer.step()

            if itr % log_every == 0:
                self.train_logger.info(
                    'Epoch {}, Train Iteration {}, loss: {:.05f}'.format(
                        self.epoch_count, 
                        itr,
                        loss.item()
                    )
                )
        return preds.detach(), confs.detach(), lbls.detach()
        
    def validate(self, dataloader, losses, binary):
        with torch.no_grad():
            epoch_start_time = time.time()  # grab epoch start time
    
            self.encoder.eval()  # put model into testing mode
            if self.late_fusion: self.encoder2.eval()
            self.decoder.eval()  # put model into testing mode
            preds = torch.zeros(10, 1)
            confs = torch.zeros(10, self.args.num_classes)
            lbls = torch.zeros(10, 1)
            with torch.no_grad():
                for itr, batch in enumerate(dataloader, start=1):
                    itr_start_time = time.time()

                    _, target, _, conf = self._get_outputs(batch) if not self.late_fusion \
                                            else self._get_outputs_late_fusion(batch)
                    confs[itr-1, :] = conf
                    
                    if binary:
                        target = batch[1].to(self.device).view(1,-1)
                        lbls[itr-1] = target.item()
                        loss = self.loss(conf, target)
                        preds[itr-1] = (conf > 0.5).item()
                    else:
                        target = batch[1].long().to(self.device)
                        _, ti = target.topk(1)
                        lbls[itr-1] = ti[0].view(-1).long().item()
                        loss = self.loss(conf, ti[0].view(-1).long())
                        _, pred = conf.topk(1)
                        preds[itr-1] = pred.item()

                    losses.append(loss.item()) #  log the loss

                    self.test_logger.info(
                        'Epoch {}, Test Iteration {}, loss: {:.05f}'.format(
                            self.epoch_count, 
                            itr, 
                            loss.item()
                        )
                    )
        return preds.detach(), confs.detach(), lbls.detach()
    
    def _get_outputs(self, batch):
        hidden = self.encoder.initHidden()

        encoder_outputs = torch.zeros(self.MAX_LEN, 1, self.encoder.hidden_size, device=self.device)

        inputs = batch[0].double()
        if self.tform:
            inputs = self.tform(inputs)
        inputs = inputs.to(device)
        inputs = inputs.view(inputs.shape[1], inputs.shape[0], inputs.shape[2])
        target = batch[1].to(self.device)
        encoder_output, encoder_hidden = self.encoder(inputs, hidden)
        encoder_outputs[:encoder_output.shape[0],:] = encoder_output

        decoder_out = self.decoder(encoder_outputs.view(1,-1))

        return inputs, target, encoder_outputs, decoder_out
    
    def _get_outputs_late_fusion(self, batch):
        gaze_hidden = self.encoder1.initHidden()
        joy_hidden = self.encoder2.initHidden()

        encoder_outputs = torch.zeros(self.MAX_LEN, 1, self.encoder.hidden_size*2, device=self.device)

        inputs = batch[0].double()
        if self.tform:
            inputs = self.tform(inputs)
        inputs = inputs.to(device)
        if self.args.embed in ['real', 'diff'] and args.data_set == 'HARMONIC':
            gaze_inputs = inputs[:, :, :3]
            joy_inputs = inputs[:, :, 3:]
        elif self.args.embed in ['real', 'diff'] and args.data_set == 'ActReact':
            gaze_inputs = inputs[:, :, :2]
            joy_inputs = inputs[:, :,2:]    
        else:
            gaze_inputs = inputs[:, :, :100]
            joy_inputs = inputs[:, :, 100:]
        
        gaze_inputs = gaze_inputs.view(gaze_inputs.shape[1], gaze_inputs.shape[0], gaze_inputs.shape[2])
        joy_inputs = joy_inputs.view(joy_inputs.shape[1], joy_inputs.shape[0], joy_inputs.shape[2])
        
        target = batch[1].to(self.device)
        
        encoder_output1, gaze_hidden = self.encoder1(gaze_inputs, gaze_hidden)
        encoder_output2, joy_hidden = self.encoder2(joy_inputs, joy_hidden)
        
        encoder_outputs[:encoder_output1.shape[0],:, :self.encoder1.hidden_size] = encoder_output1
        encoder_outputs[:encoder_output2.shape[0],:, self.encoder1.hidden_size:] = encoder_output2

        decoder_out = self.decoder(encoder_outputs.view(1,-1))

        return inputs, target, encoder_outputs, decoder_out
    
    def test(self, preds, confs, lbls):
        
        def one_hot(vec, num_classes):
            if num_classes == 1:
                act_classes = 2
            else:
                act_classes = num_classes
            ans = np.zeros((vec.shape[0], act_classes))
            for i in range(vec.shape[0]):
                ans[i, vec[i].int()] = 1
            return ans
        
        acc = (torch.sum(lbls == preds).double() / lbls.shape[0]).numpy()
        oh_lbls = one_hot(lbls, self.args.num_classes)
        mAP = average_precision_score(oh_lbls, confs) 
        return acc, mAP
        
    def fit(
        self, 
        trainloader,
        valloader,
        patience,
        eps,
        checkpoint='checkpoint.model',
        binary=False,
        plotting=False,
        log_every=1,
        save_every=125
    ):
        """

        """
        def save(checkpoint, lf=False):
            torch.save(  # save the model to the checkpoint
                {
                    'encoder': self.encoder.state_dict(), 
                    'encoder2': self.encoder2.state_dict() if lf else None, 
                    'decoder': self.decoder.state_dict(), 
                    'args': self.args,
                },
                checkpoint
            )
        
        checkpoint = os.path.join(self.resultsdir, checkpoint)
        train_plot_losses = []
        val_plot_losses = []
        
        train_plot_accs = []
        val_plot_accs = []
        
        train_plot_mAPs = []
        val_plot_mAPs = []
        
        
        accs = []
        mAP = []
#         patience_counter = 0
        bests = torch.ones(5)*10000000
        names = ['','','','','']
        save_me = False
        for epoch in range(1,self.epoch_num+1):
            epoch_start_time = time.time()
            
            self.epoch_count = epoch
            
            train_losses = []
            val_losses = []
            
            train_accs = []
            valid_accs = []
            
            train_mAPs = []
            valid_mAPs = []
            
            preds_train, confs_train, lbls_train = self.train(trainloader, train_losses, binary, log_every)
            train_loss_avg = np.mean(train_losses)
            train_plot_losses.append(train_loss_avg)
            
            preds_valid, confs_valid, lbls_valid = self.validate(valloader, val_losses, binary)
            val_loss_avg = np.mean(val_losses)
            val_plot_losses.append(val_loss_avg)
            
            train_acc, train_mAP = self.test(preds_train, confs_train, lbls_train)
            valid_acc, valid_mAP = self.test(preds_valid, confs_valid, lbls_valid)
            
            train_plot_accs.append(train_acc)
            val_plot_accs.append(valid_acc)
            
            train_plot_mAPs.append(train_mAP)
            val_plot_mAPs.append(valid_mAP)
                
            fig, ax = plt.subplots()
            ax.plot(train_plot_losses)
            ax.plot(val_plot_losses, alpha = 0.5)
            ax.set_ylim(0, 3)
            plt.savefig(self.plot_file)
            if plotting:
                plt.show()
            plt.close()
            
            fig, ax = plt.subplots()
            ax.plot(train_plot_accs)
            ax.plot(val_plot_accs, alpha = 0.5)
            ax.set_ylim(0, 1.1)
            plt.savefig(os.path.join(self.resultsdir, 'acc_plot.png'))
            if plotting:
                plt.show()
            plt.close()
            
            fig, ax = plt.subplots()
            ax.plot(train_plot_mAPs)
            ax.plot(val_plot_mAPs, alpha = 0.5)
            
            ax.set_ylim(0, 1.1)
            plt.savefig(os.path.join(self.resultsdir, 'mAP_plot.png'))
            if plotting:
                plt.show()
            plt.close()
            
            comp = val_loss_avg < bests
            if torch.sum(comp) > 0:
                old = names[torch.argmax(bests)]
                if old != '':
                    os.remove(old)
                
                ckptname = '_{:04d}.'.format(epoch).join(checkpoint.split('.'))
                names[torch.argmax(bests)] = ckptname
                bests[torch.argmax(bests)] = val_loss_avg
                save(ckptname, self.args.late_fusion)
            
            if epoch % save_every == 0:
                ckptname = '_{:04d}.'.format((epoch // save_every) * save_every).join(checkpoint.split('.'))
                save(ckptname, self.args.late_fusion)

            epoch_time = time.time() - epoch_start_time  # grab epoch end time

def get_max_len(train, test, count_size):
    MAX_LEN = -1
    counts = np.zeros(count_size)
    for i,batch in enumerate(train):
        if i > len(train) - 2:
            break
        counts[np.argmax(batch[1])] += 1
        if batch[0].shape[0] > MAX_LEN:
            MAX_LEN = batch[0].shape[0]

    for i,batch in enumerate(test):
        if i > len(test) - 2:
            break
        counts[np.argmax(batch[1])] += 1

        if batch[0].shape[0] > MAX_LEN:
            MAX_LEN = batch[0].shape[0] 
    return MAX_LEN, counts
            
def classification(args, epochs, device, log_every, hidden_size, streams, embed, task):
    if args.task == 'macro':
        dsetclass = HARMONICMacroClassificationDataset if args.data_set == 'HARMONIC' else ActReactMacroClassificationDataset
    else:
        dsetclass = HARMONICMicroClassificationDataset if args.data_set == 'HARMONIC' else ActReactMicroClassificationDataset
    
    actreact_train = dsetclass(
        streams=args.streams, 
        embed=args.embed, 
        frame_set=args.frame_set['train'],
        part_set=args.validation
    )
    actreact_test = dsetclass(
        streams=args.streams, 
        embed=args.embed, 
        train=False, 
        frame_set=args.frame_set['test'],
        part_set=args.validation
    )
    
    MAX_LEN, counts = get_max_len(actreact_train, actreact_test, args.num_classes)
    args.max_len = MAX_LEN
    
    if args.task == 'micro':
        loss = nn.CrossEntropyLoss(weight=torch.from_numpy(counts/np.sum(counts))).to(args.device)
    elif args.task == 'macro':
        loss = nn.CrossEntropyLoss(weight=torch.from_numpy(counts/np.sum(counts))).to(args.device)
        #nn.BCEWithLogitsLoss().to(device)
    
    if args.late_fusion:
        if args.data_set == 'HARMONIC':
            fs = 3 if args.embed in ['real', 'diff'] else 100
        else:
            fs = 2 if args.embed in ['real', 'diff'] else 100
        encoder = EncoderRNN(
            len(actreact_train), 
            int(args.hidden_size/2), 
            1, 
            fs, # gx, gy, gc
            num_layers=2
        ).to(args.device)
    else:
        encoder = EncoderRNN(
            len(actreact_train), 
            args.hidden_size, 
            1, 
            actreact_train.tot_embedding_size, 
            num_layers=2
        ).to(args.device)
    
    if args.late_fusion:
        if args.data_set == 'HARMONIC':
            fs = 5 if args.embed in ['real', 'diff'] else 100
        else:
            fs = 2 if args.embed in ['real', 'diff'] else 100
            
        encoder2 = EncoderRNN(
            len(actreact_train), 
            int(args.hidden_size/2), 
            1, 
            fs, #jx, jy, jm1, jm2, jm3
            num_layers=2
        ).to(args.device)
    else:
        encoder2 = None
    
    decoder = DecoderMLP(
        [
            args.num_classes, 
            int(args.hidden_size/2), 
            MAX_LEN*args.hidden_size
        ], 
        MAX_LEN*args.hidden_size
    ).to(args.device)
    
    train, val = torch.utils.data.random_split(
        actreact_train, 
        [
            int(.9*len(actreact_train)), 
            len(actreact_train) - int(.9*len(actreact_train))
        ]
    )

    trainloader = torch.utils.data.DataLoader(
        actreact_train, 
        batch_size=1, 
        sampler=torch.utils.data.RandomSampler(
            data_source=train.indices, 
            replacement=True, 
            num_samples=100
        ),
        shuffle=False
    )

    valloader = torch.utils.data.DataLoader(
        actreact_train, 
        batch_size=1, 
        sampler=torch.utils.data.RandomSampler(
            data_source=val.indices, 
            replacement=True, 
            num_samples=10
        ),
        shuffle=False
    )

    
    if args.embed != 'binary':
        harmonic = args.data_set == 'HARMONIC'
        numbs = torch.load('norms/{}_{}_{}_norms.pt'.format(args.data_set, args.task, args.embed))
        means = numbs['means']
        stds = numbs['stds']
        if args.streams == 'joy':
            means = means[3:] if harmonic else means[2:]
            stds = stds[3:] if harmonic else stds[2:]
        elif args.streams == 'gaze':
            means = means[:3] if harmonic else means[:2]
            stds = stds[:3] if harmonic else stds[:2]
        if args.streams == 'both' and harmonic:
            num_feats = 5
        elif args.streams == 'both':
            num_feats = 4
        elif args.streams == 'gaze' and harmonic:
            num_feats = 3
        else:
            num_feats = 2
        tform = Normalize(means.double(), stds.double(), num_feats) if args.embed != 'binary' else None#either 5, 3, 2,
    else:
        tform = None
    args.tform = tform
    
    s = Solver(
        encoder,
        decoder,
        MAX_LEN,
        counts,
        args.epochs, 
        args.learning_rate, 
        loss,
        resultsdir = args.results_dir,
        train_log_file='train.log',
        test_log_file='test.log',
        plot_file='loss_plot.png',
        device=args.device,
        args=args,
        encoder2=encoder2,
        tform = tform
    )

    s.fit(
        trainloader,
        valloader,
        patience=101,
        eps=1e-6,
        checkpoint='checkpoint.model',
        log_every=log_every,
        binary = False,#task == 'macro',
    )
    
    return 
            
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-e', '--epochs', type=int, help='Total number of epochs', default=500)
    parser.add_argument('-d', '--device', type=str, help='cuda or cpu', default='cpu')
    parser.add_argument('-log','--log_every', type=int, help='How often to log', default=5)
    parser.add_argument('-t', '--task', type=str, help='macro or micro', default='micro')
    parser.add_argument('-s', '--streams', type=str, help='gaze, joy, or both', default='both')
    parser.add_argument('-em', '--embed', type=str, help='binary, real, or diff', default='binary')
    parser.add_argument('-hs', '--hidden_size', type=int, help='hidden dimension size', default=256)
    parser.add_argument('-r', '--results_dir', type=str, help='directory to store results', default='results')
    parser.add_argument('-lf', '--late_fusion', type=bool, help='do late fusion', default=False)
    parser.add_argument('-data', '--data_set', type=str, help='ActReact or HARMONIC', default='HARMONIC')
    parser.add_argument('-c', '--clip', type=float, help='gradient clipping', default=0.0)
    parser.add_argument('-lr', '--learning_rate', type=float, help='learning rate', default=1e-3)
    parser.add_argument('-v', '--validation', type=str, help='do participant cross validation', default=None)
    args = parser.parse_args()
    if args.device == 'cuda' and not torch.cuda.is_available():
        raise Exception('Device {} is not available.'.format(args.device))
    if args.streams != 'both' and args.late_fusion == True:
        raise Exception('Must have streams > 1 for late fusion. Your stream is {}.'.format(args.streams))
    if args.data_set not in ['HARMONIC', 'ActReact']:
        raise Exception('Data set must be one of {}. Your data set is {}.'.format(['HARMONIC', 'ActReact'], args.data_set))
    args.device = torch.device(args.device)
    if args.task =='micro':
        args.num_classes = 3
    else:
        args.num_classes = 5
        
    if args.data_set == 'HARMONIC':
        if not args.validation:
            args.frame_set = torch.load('splits/split_{}_{}.pt'.format(args.data_set, args.task))
        else:
            args.frame_set = {'train':None, 'test':None}
    else:
        args.frame_set = {'train':None, 'test':None}
        
    classification(args, args.epochs, args.device, args.log_every, args.hidden_size, args.streams, args.embed, args.task)
    
