from __future__ import unicode_literals, print_function, division

import numpy as np
import agent

import matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib import animation, rc

import os

import torch
import torch.nn as nn
import torch.utils.data

import time
import math

from io import open
import unicodedata
import string
import re
import random

from torch import optim
import torch.nn.functional as F

from sklearn.metrics import confusion_matrix, average_precision_score
from sklearn.utils.multiclass import unique_labels

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
MAX_LENGTH = 10

class EncoderRNN(nn.Module):
    def __init__(self, input_size, hidden_size, batch_size, features_size=100, num_layers=1):
        super(EncoderRNN, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.batch_size = batch_size
        self.features_size = features_size

        self.gru = nn.GRU(self.features_size, hidden_size, num_layers=self.num_layers)

    def forward(self, input, hidden):
        output, hidden = self.gru(input.double(), hidden)
        return output, hidden

    def initHidden(self):
        return torch.zeros(self.num_layers, self.batch_size, self.hidden_size, device=device)

class DecoderMLP(nn.Module):
    def __init__(self, layer_sizes, input_size):
        super(DecoderMLP, self).__init__()
        self.decoder_layers = nn.ModuleList(
            self.generate_decoder_layers(
                input_size, 
                layer_sizes
            )
        )
    
    @staticmethod
    def generate_decoder_layers(input_size, layer_sizes):
        layers = []
        layer_sizes = np.flip(layer_sizes,axis=0)
        for layerID in range(len(layer_sizes) - 1):
            if layerID == len(layer_sizes) - 2: # If last layer, no activation
                layers.append(
                    nn.Sequential(
                        nn.Linear(
                            layer_sizes[layerID], 
                            layer_sizes[layerID + 1]
                        ),
#                         nn.Tanh(),
                    )
                )
            else: # General building block
                layers.append(
                    nn.Sequential(
                        nn.Linear(
                            layer_sizes[layerID], 
                            layer_sizes[layerID + 1]
                        ),
                    nn.ReLU(True),
                    )
                )
        return layers
    
    def forward(self, x):
        for layer in self.decoder_layers:
            x = layer(x)
        return x

class SemanticEncoderDecoder(nn.Module):
    def __init__(self, encoder, decoder, loss):
        super(SemanticEncoderDecoder, self).__init__()
        self.encoder = encoder
        self.decoder = decoder
        self.loss = loss
        
    def forward(self, x, hidden):
        output, hidden = self.encoder(x, hidden)
        output = self.decoder(output)
        return output, hidden
    
    
class DecoderRNN(nn.Module):
    def __init__(self, hidden_size, output_size, num_layers=1):
        super(DecoderRNN, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        self.embedding = nn.Embedding(output_size, hidden_size)
        self.gru = nn.GRU(hidden_size, hidden_size, num_layers=self.num_layers)
        self.out = nn.Linear(hidden_size, output_size)
        self.softmax = nn.LogSoftmax(dim=1)

    def forward(self, input, hidden):
        output = self.embedding(input).view(self.num_layers, 1, -1)
        output = F.relu(output)
        output, hidden = self.gru(output, hidden)
        output = self.softmax(self.out(output[0]))
        return output, hidden

    def initHidden(self):
        return torch.zeros(self.num_layers, 1, self.hidden_size, device=device)    
    
class AttnDecoderRNN(nn.Module):
    def __init__(self, hidden_size, output_size, dropout_p=0.1, max_length=MAX_LENGTH, num_layers=1):
        super(AttnDecoderRNN, self).__init__()
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.dropout_p = dropout_p
        self.max_length = max_length
        self.num_layers = num_layers

        self.embedding = nn.Embedding(self.output_size, self.hidden_size)
        self.attn = nn.Linear(self.hidden_size * 2, self.max_length)
        self.attn_combine = nn.Linear(self.hidden_size * 2, self.hidden_size)
        self.dropout = nn.Dropout(self.dropout_p)
        self.gru = nn.GRU(self.hidden_size, self.hidden_size, num_layers=self.num_layers)
        self.out = nn.Linear(self.hidden_size, self.output_size)

    def forward(self, input, hidden, encoder_outputs):
        embedded = self.embedding(input).view(self.num_layers, 1, -1)
        embedded = self.dropout(embedded)

        attn_weights = F.softmax(
            self.attn(torch.cat((embedded[0], hidden[0]), 1)), dim=1)
        attn_applied = torch.bmm(attn_weights.unsqueeze(0),
                                 encoder_outputs.unsqueeze(0))

        output = torch.cat((embedded[0], attn_applied[0]), 1)
        output = self.attn_combine(output).unsqueeze(0)

        output = F.relu(output)
        output, hidden = self.gru(output, hidden)

        output = F.log_softmax(self.out(output[0]), dim=1)
        return output, hidden, attn_weights

    def initHidden(self):
        return torch.zeros(self.num_layers, 1, self.hidden_size, device=device)