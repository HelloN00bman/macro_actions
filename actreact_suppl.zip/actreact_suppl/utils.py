import os
import sys

import numpy as np
import pandas as pd
import pickle as pkl

def one_hot_encode(values, num=None):
    if num == None:
        n_values = np.max(values) + 1
    else:
        n_values = num
    return np.eye(n_values)[values]

def get_control_modes(trials):
    control_modes = []
    for trial in trials:
        with open(os.path.join(trial, 'text_data', 'control_mode.txt')) as mode_f:
            control_modes.append(int(mode_f.read().strip()))
    return control_modes

def get_etra_trials(home):
    parts = [os.path.join(home, x) for x in sorted(os.listdir(home)) if os.path.isdir(os.path.join(home, x))]
    all_trials = []
    for part in parts:
        ts = [os.path.join(part, x) for x in os.listdir(part)]
        all_trials += ts
    
    all_trials = np.array(all_trials)    
    
    return all_trials

def get_trials(home, assistance=None):
    parts = [os.path.join(home, x, 'run') for x in sorted(os.listdir(home)) if 'p1' in x]
    all_trials = []
    for part in parts:
        ts = [os.path.join(part, x) for x in os.listdir(part)]
        all_trials += ts
    
    all_trials = np.array(all_trials)    
    
    if assistance != None:
        ctrl_modes = get_control_modes(all_trials)
        inds = np.where(np.array(ctrl_modes) == assistance)[0]
        all_trials = all_trials[inds]
        
    return all_trials

def convert_modes(button_presses):
    ### Convert mode from 0/1 to mode \in {0,1,2}
    inds = np.where(np.diff(button_presses)>0)[0]+1 # find indices when the button was pressed
    inds = np.hstack((0, inds))
    inds = np.hstack((inds, len(button_presses))) 

    modes = np.zeros(button_presses.shape[0])
    mode = 0             
    for i,ind in enumerate(inds):  
        if i < inds.shape[0]-1:
            modes[ind:inds[i+1]] = mode
        mode += 1
        mode = mode % 3
    return modes


def get_etra_data(trials):
    gazes = {}
    for trial in trials:
        jnum = int(trial.split('/')[-1])-1
        gaze_file = pd.read_csv(os.path.join(trial, 'journal-000{}.txt'.format(jnum)), sep='\t', header=1)
        gaze = np.zeros((4, gaze_file.eye_x.values.shape[0]))
        gaze[0,:] = gaze_file.eye_x.values
        gaze[1,:] = gaze_file.eye_y.values
        gaze[2,:] = gaze_file.eye_valid.values
        gaze[3,:] = gaze_file.timestamp.values
        gazes[trial] = gaze
    return gazes

def get_etra_labels(trials):
    gazes = {}
    for trial in trials:
        gaze_file = pd.read_csv(os.path.join(trial, 'reviewed.csv'), header=None)
        gaze = np.zeros((2, gaze_file[0].values.shape[0]))
        gaze[0,:] = gaze_file[1].values
        gaze[1,:] = gaze_file[2].values
        gazes[trial] = gaze
    return gazes

def get_gaze_data(trials):
    gazes = {}
    for trial in trials:
        gaze_file = pd.read_csv(os.path.join(trial, 'text_data', 'gaze_positions.csv'))
        gaze = np.zeros((5, gaze_file.norm_pos_x.values.shape[0]))
        gaze[0,:] = gaze_file.norm_pos_x.values
        gaze[1,:] = gaze_file.norm_pos_y.values
        gaze[2,:] = gaze_file.confidence.values
        gaze[3,:] = gaze_file.timestamp.values
        gaze[4,:] = gaze_file.world_index_corrected.values
        gazes[trial] = gaze
    return gazes

def get_phys_labels(home, trials):
    pass

def get_eye_data(trials):
    eyes = {}
    for trial in trials:
        eye_file = pd.read_csv(os.path.join(trial, 'text_data', 'gaze_positions.csv'))
        eye = np.zeros((6, eye_file.norm_pos_x.values.shape[0]))
        eye[0,:] = eye_file.eye_center0_3d_x.values
        eye[1,:] = eye_file.eye_center0_3d_y.values
        eye[2,:] = eye_file.eye_center0_3d_x.values
        eye[3,:] = eye_file.eye_center0_3d_y.values
        eye[4,:] = eye_file.confidence.values
        eye[5,:] = eye_file.world_index_corrected.values
        eyes[trial] = eye
    return eyes

def get_joystick_data(trials):
    joys = {}
    for trial in trials:
        joy_file = pd.read_csv(os.path.join(trial, 'text_data', 'ada_joy.csv'))
        joy = np.zeros((5, joy_file.axes_x.values.shape[0]))
        joy[0,:] = joy_file.axes_x.values
        joy[1,:] = joy_file.axes_y.values
        joy[2,:] = joy_file.buttons_0.values
        joy[3,:] = joy_file.timestamp.values
        joy[4,:] = joy_file.world_index_corrected.values
        joys[trial] = joy
    return joys

def smooth_gaze(gazes):
    smoothed = {}
    for trial,cur_gaze in gazes.items():
        frames = np.unique(cur_gaze[-1])
        smooth_gaze = np.zeros((3, int(np.max(frames))+1))
        for i in frames:
            world_ind = cur_gaze[-1]
            ind = int(i)
            cur_inds = np.where(world_ind == ind)[0]
            confs = cur_gaze[2,cur_inds]
            high_conf_inds = confs>.9
            
            smooth_gaze[0,ind] = np.mean(cur_gaze[0,np.where(world_ind == ind)[0]][high_conf_inds])
            smooth_gaze[1,ind] = np.mean(cur_gaze[1,np.where(world_ind == ind)[0]][high_conf_inds])
            smooth_gaze[2,ind] = np.mean(cur_gaze[2,np.where(world_ind == ind)[0]][high_conf_inds])
            
        smoothed[trial] = smooth_gaze
    return smoothed


def interp_gaze(gazes, frate):
    interped = {}
    for trial,cur_gaze in gazes.items():
        world_timestamps = np.load(os.path.join(trial, 'videos/world_timestamps.npy'))
        start = world_timestamps[0]
        end = world_timestamps[-1]

        stamps = np.arange(start, end, frate)

        interp_x = np.interp(stamps, gazes[trial][3,:], np.clip(gazes[trial][0,:], 0, 1))
        interp_y = np.interp(stamps, gazes[trial][3,:], np.clip(gazes[trial][1,:], 0, 1))
        
        interped[trial] = np.vstack((interp_x, interp_y))
    return interped

def interp_joy(joys, frate):
    interped = {}
    for trial,cur_joy in joys.items():
        world_timestamps = np.load(os.path.join(trial, 'videos/world_timestamps.npy'))
        start = world_timestamps[0]
        end = world_timestamps[-1]

        stamps = np.arange(start, end, frate)

        interp_x = np.interp(stamps, cur_joy[3,:], np.clip(cur_joy[0,:], -1, 1))
        interp_y = np.interp(stamps, cur_joy[3,:], np.clip(cur_joy[1,:], -1, 1))
        interp_m = convert_modes(np.interp(stamps, cur_joy[3,:], cur_joy[2,:]))
        
        interped[trial] = np.vstack((interp_x, interp_y, interp_m))
    return interped

def smooth_eye(eyes):
    smoothed = {}
    for trial,cur_eye in eyes.items():
        frames = np.unique(cur_eye[-1])
        smooth_eye = np.zeros((5, int(np.max(frames))+1))
        for i in frames:
            world_ind = cur_eye[-1]
            ind = int(i)
            cur_inds = np.where(world_ind == ind)[0]
            confs = cur_eye[4,cur_inds]
            high_conf_inds = confs>.9
            
            smooth_eye[0,ind] = np.mean(cur_eye[0,np.where(world_ind == ind)[0]][high_conf_inds])
            smooth_eye[1,ind] = np.mean(cur_eye[1,np.where(world_ind == ind)[0]][high_conf_inds])
            smooth_eye[2,ind] = np.mean(cur_eye[2,np.where(world_ind == ind)[0]][high_conf_inds])
            smooth_eye[3,ind] = np.mean(cur_eye[2,np.where(world_ind == ind)[0]][high_conf_inds])
            smooth_eye[4,ind] = np.mean(cur_eye[2,np.where(world_ind == ind)[0]][high_conf_inds])
            
        smoothed[trial] = smooth_eye
    return smoothed

def smooth_joystick(joys):
    smoothed = {}
    for trial,cur_joy in joys.items():
        frames = np.unique(cur_joy[-1])
        smooth_joy = np.zeros((5, int(np.max(frames))+1))
        for i in frames:
            world_ind = cur_joy[-1]
            ind = int(i)
            smooth_joy[0,ind] = np.mean(cur_joy[0,np.where(world_ind == ind)[0]])
            smooth_joy[1,ind] = np.mean(cur_joy[1,np.where(world_ind == ind)[0]])
            smooth_joy[2,ind] = np.mean(cur_joy[2,np.where(world_ind == ind)[0]])>=.5
        
        smooth_joy[2:,:] = one_hot_encode(convert_modes(smooth_joy[2,:]).astype(int),3).T
        smoothed[trial] = smooth_joy
    return smoothed
        
def save(X, filename, force=False):
    if os.path.isfile(filename) and not force:
        return False
    
    with open(filename, 'wb') as f:
        pkl.dump(X, f)
    return True

def load(filename):
    if os.path.isfile(filename):
        with open(filename, 'rb') as f:
            data = pkl.load(f)
        return data
    return False
