### Included here
1. Scripts to run experiments in `run_scripts` directory
   * Synthetic data can be generated
   * Real data experiments will require downloading HARMONIC  
2. `create_vis_dataset.ipynb` allows you to generate and visualize videos from the synthetic dataset.
3. HARMONIC micro and macro action labels are provided in the directories `ibdt_lbls` and `macro_lbls`, respectively.
4. Standardization norms are provided in the `norms` directory.
5. The HARMONIC train/test split is provided in `splits`.
6. `testing_notebook.ipynb` provides code to test the trained models.


